﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KaikkienAiheidenKertaus
{
    public class Car
    {
        // Propertys
       //public string Merkki { get; set; }
       //public int Vuosimalli { get; set; }

        // Constructors
        //public Car(string merkki, int vuosimalli)
        //{
        //    Merkki = merkki;
        //    Vuosimalli = vuosimalli;
        //}

        //// Methods
        //public void carsPresentation()
        //{
        //    Console.WriteLine($"Tämä on {Merkki} ja vuosimallia {Vuosimalli}.");
        //}
    

    }
}
