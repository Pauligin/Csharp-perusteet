﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Harjoitus26
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Anna luku: ");
            int luku = int.Parse(Console.ReadLine());

            for (int a = 1; a <= luku; a++)
            {
                Console.WriteLine(a);

                Console.ReadKey();
            }
        }

    }
}
