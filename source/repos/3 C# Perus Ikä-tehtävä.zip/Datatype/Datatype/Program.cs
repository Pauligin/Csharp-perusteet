﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datatype
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Syötä ikäsi: ");
            string ikä = Console.ReadLine();

            Console.WriteLine("Olet " + ikä + " vuotta.");
        }
    }
}
