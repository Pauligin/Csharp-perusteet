﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datatypes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kuinka vanha olet?");
            string userInput = Console.ReadLine();
            int age = int.Parse(userInput);
            Console.WriteLine("Olet " + age + " vuotta vanha.");
        }
    }
}
