﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpHarj
{
    class Topping
    {
        // Property - eli data, jota objektissa on tallessa
        public string Name { get; set; }
        // Voisi olla muuta dataa


        // Constructors- suoritettava koodi, kun luodaan luokasta objekti
        
        public Topping(string name)
        {
            Name = name;

        }

        // Method

    }
}
